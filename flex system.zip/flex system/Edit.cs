﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace flex_system_last
{
    public partial class Edit : Form
    {
        public Edit()
        {
            InitializeComponent();
        }

        private void Edits_Click(object sender, EventArgs e)
        {
            string id = IDs.Text;
            //if(te)

        }

        private void IDs_TextChanged(object sender, EventArgs e)
        {
            

        }
    }
}
