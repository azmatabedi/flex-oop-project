﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace flex_system_last
{
    public class Student
    {
        string name;
        string id;
        string batch;
        string ds;
        string marks;
        string phone;
        string address;
        

        public string Name { get => name; set => name = value; }
        public string Id { get => id; set => id = value; }
        public string Batch { get => batch; set => batch = value; }
        public string Ds { get => ds; set => ds = value; }
        public string Marks { get => marks; set => marks = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Address { get => address; set => address = value; }
       public Student() { }
       public Student( string name,string id,string batch,string department ,string phone,string address)
        {
            this.Name = name;
            this.id=id;
            this.batch = batch;
            this.ds = department;
            this.phone = phone;
            this.address = address;
          





        }

    }
}
