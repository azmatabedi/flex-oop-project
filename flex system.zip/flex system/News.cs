﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;

namespace flex_system_last
{
    public partial class News : Form
    {
        Teacher teacher;
        IFirebaseClient client;
        Counter count;
        public News(Teacher teacher)
        {
            this.teacher = teacher;
            InitializeComponent();
        }
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5el7PEgL8sOhY7uACJt9VRYHtaC1O3No9nLXE02z",
            BasePath = "https://flex-system-30389.firebaseio.com/"
        };
        private async void Save_Click(object sender, EventArgs e)
        {
            string name = Names.Text;
            string id = IDs.Text;
            string batch = Batchs.Text;
            string department = Departments.Text;
            string phone = Phones.Text;
            string address = Address.Text;
            Student student = new Student()
            {
                Name = name,
                Id = id,
                Address = address,
                Batch = batch,
                Ds = department,
                Phone = phone
            };
            FirebaseResponse get = client.Get("Information/Counter/Students/count");
            count= get.ResultAs<Counter>();
            int xount = count.Count++;
            count.Id = id;
            MessageBox.Show("value of X: " + xount.ToString());
            xount++;
            setStudents(xount,id);
            try
            {
                SetResponse setResponse = await client.SetTaskAsync(@"Information/student/" + student.Id, student);
                MessageBox.Show("Student Added");

            }
            catch
            {
                MessageBox.Show("Something Wrong");
            }
            
        }
        private void setStudents(int xount,string id)
        {
                try
                {
                    FirebaseResponse set =  client.Set("Information/Counter/Students/count", count);
                    MessageBox.Show("updated");
                    try
                    {
                        SetResponse setRes =  client.Set("Information/Counter/ID/" + xount.ToString(), count.Id);
                        MessageBox.Show("ID added");
                    }
                    catch
                    {
                        MessageBox.Show("ID not added");
                    }
                }
                catch
                {
                    MessageBox.Show("not updated");
                }
        }
        private void News_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);
            if (client == null)
            {
                MessageBox.Show("server not Responding");
            }
            FirebaseResponse firebaseresponce = client.Get(@"Information/Counter");
            count = firebaseresponce.ResultAs<Counter>();
        }

        private void deleteb_Click(object sender, EventArgs e)
        {
            Delete delete = new Delete(teacher);
            this.Hide();
            delete.Show();
        }

        
        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Upload_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog open = new OpenFileDialog())
            {
                open.Filter = "Image Files(*.jpg;*.jpeg;*.gif;*.bmp)|*.jpg;*.jpeg;*.gif;*.bmp";
                if (open.ShowDialog() == DialogResult.OK)
                {

                    pictureBox1.Image = new Bitmap(open.FileName);

                }
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
         


        }
    }
}