﻿namespace flex_system_last
{
    partial class Homef
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CNICt = new System.Windows.Forms.TextBox();
            this.Departmentt = new System.Windows.Forms.TextBox();
            this.DOBt = new System.Windows.Forms.TextBox();
            this.Gendert = new System.Windows.Forms.TextBox();
            this.Namet = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.editb = new System.Windows.Forms.Button();
            this.marksb = new System.Windows.Forms.Button();
            this.deleteb = new System.Windows.Forms.Button();
            this.news = new System.Windows.Forms.Button();
            this.searchb = new System.Windows.Forms.Button();
            this.homeb = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CNICt
            // 
            this.CNICt.Location = new System.Drawing.Point(337, 318);
            this.CNICt.Name = "CNICt";
            this.CNICt.Size = new System.Drawing.Size(100, 20);
            this.CNICt.TabIndex = 19;
            // 
            // Departmentt
            // 
            this.Departmentt.Location = new System.Drawing.Point(337, 267);
            this.Departmentt.Name = "Departmentt";
            this.Departmentt.Size = new System.Drawing.Size(100, 20);
            this.Departmentt.TabIndex = 18;
            // 
            // DOBt
            // 
            this.DOBt.Location = new System.Drawing.Point(337, 215);
            this.DOBt.Name = "DOBt";
            this.DOBt.Size = new System.Drawing.Size(100, 20);
            this.DOBt.TabIndex = 17;
            // 
            // Gendert
            // 
            this.Gendert.Location = new System.Drawing.Point(337, 163);
            this.Gendert.Name = "Gendert";
            this.Gendert.Size = new System.Drawing.Size(100, 20);
            this.Gendert.TabIndex = 16;
            // 
            // Namet
            // 
            this.Namet.Location = new System.Drawing.Point(337, 113);
            this.Namet.Name = "Namet";
            this.Namet.Size = new System.Drawing.Size(100, 20);
            this.Namet.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(180, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "CNIC";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(180, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(180, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "DOB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(180, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Gender";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(180, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.editb);
            this.panel1.Controls.Add(this.marksb);
            this.panel1.Controls.Add(this.deleteb);
            this.panel1.Controls.Add(this.news);
            this.panel1.Controls.Add(this.searchb);
            this.panel1.Controls.Add(this.homeb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(80, 450);
            this.panel1.TabIndex = 20;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(5, 222);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 6;
            this.exit.Text = "exit";
            this.exit.UseVisualStyleBackColor = true;
            // 
            // editb
            // 
            this.editb.Location = new System.Drawing.Point(2, 184);
            this.editb.Name = "editb";
            this.editb.Size = new System.Drawing.Size(75, 23);
            this.editb.TabIndex = 5;
            this.editb.Text = "edit";
            this.editb.UseVisualStyleBackColor = true;
            // 
            // marksb
            // 
            this.marksb.Location = new System.Drawing.Point(2, 139);
            this.marksb.Name = "marksb";
            this.marksb.Size = new System.Drawing.Size(75, 23);
            this.marksb.TabIndex = 4;
            this.marksb.Text = "marks";
            this.marksb.UseVisualStyleBackColor = true;
            // 
            // deleteb
            // 
            this.deleteb.Location = new System.Drawing.Point(0, 110);
            this.deleteb.Name = "deleteb";
            this.deleteb.Size = new System.Drawing.Size(75, 23);
            this.deleteb.TabIndex = 3;
            this.deleteb.Text = "delete";
            this.deleteb.UseVisualStyleBackColor = true;
            this.deleteb.Click += new System.EventHandler(this.deleteb_Click);
            // 
            // news
            // 
            this.news.Location = new System.Drawing.Point(2, 70);
            this.news.Name = "news";
            this.news.Size = new System.Drawing.Size(75, 23);
            this.news.TabIndex = 2;
            this.news.Text = "new";
            this.news.UseVisualStyleBackColor = true;
            this.news.Click += new System.EventHandler(this.News_Click);
            // 
            // searchb
            // 
            this.searchb.Location = new System.Drawing.Point(2, 32);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(75, 23);
            this.searchb.TabIndex = 1;
            this.searchb.Text = "search";
            this.searchb.UseVisualStyleBackColor = true;
            this.searchb.Click += new System.EventHandler(this.Searchb_Click);
            // 
            // homeb
            // 
            this.homeb.Location = new System.Drawing.Point(0, 3);
            this.homeb.Name = "homeb";
            this.homeb.Size = new System.Drawing.Size(75, 23);
            this.homeb.TabIndex = 0;
            this.homeb.Text = "home";
            this.homeb.UseVisualStyleBackColor = true;
            // 
            // Homef
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CNICt);
            this.Controls.Add(this.Departmentt);
            this.Controls.Add(this.DOBt);
            this.Controls.Add(this.Gendert);
            this.Controls.Add(this.Namet);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Homef";
            this.Text = "Homef";
            this.Load += new System.EventHandler(this.Homef_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox CNICt;
        private System.Windows.Forms.TextBox Departmentt;
        private System.Windows.Forms.TextBox DOBt;
        private System.Windows.Forms.TextBox Gendert;
        private System.Windows.Forms.TextBox Namet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button editb;
        private System.Windows.Forms.Button marksb;
        private System.Windows.Forms.Button deleteb;
        private System.Windows.Forms.Button news;
        private System.Windows.Forms.Button searchb;
        private System.Windows.Forms.Button homeb;
    }
}