﻿namespace flex_system_last
{
    partial class Marks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Departments = new System.Windows.Forms.TextBox();
            this.Batchs = new System.Windows.Forms.TextBox();
            this.IDs = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Names = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Markss = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.editb = new System.Windows.Forms.Button();
            this.marksb = new System.Windows.Forms.Button();
            this.deleteb = new System.Windows.Forms.Button();
            this.news = new System.Windows.Forms.Button();
            this.searchb = new System.Windows.Forms.Button();
            this.homeb = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Departments
            // 
            this.Departments.Location = new System.Drawing.Point(298, 240);
            this.Departments.Name = "Departments";
            this.Departments.Size = new System.Drawing.Size(100, 20);
            this.Departments.TabIndex = 27;
            // 
            // Batchs
            // 
            this.Batchs.Location = new System.Drawing.Point(298, 195);
            this.Batchs.Name = "Batchs";
            this.Batchs.Size = new System.Drawing.Size(100, 20);
            this.Batchs.TabIndex = 26;
            // 
            // IDs
            // 
            this.IDs.Location = new System.Drawing.Point(298, 97);
            this.IDs.Name = "IDs";
            this.IDs.Size = new System.Drawing.Size(100, 20);
            this.IDs.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(161, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(161, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Batch";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "ID";
            // 
            // Names
            // 
            this.Names.Location = new System.Drawing.Point(298, 144);
            this.Names.Name = "Names";
            this.Names.Size = new System.Drawing.Size(100, 20);
            this.Names.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(161, 292);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 30;
            this.label5.Text = "Marks";
            // 
            // Markss
            // 
            this.Markss.Location = new System.Drawing.Point(298, 285);
            this.Markss.Name = "Markss";
            this.Markss.Size = new System.Drawing.Size(100, 20);
            this.Markss.TabIndex = 31;
            this.Markss.TextChanged += new System.EventHandler(this.Markss_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.editb);
            this.panel1.Controls.Add(this.marksb);
            this.panel1.Controls.Add(this.deleteb);
            this.panel1.Controls.Add(this.news);
            this.panel1.Controls.Add(this.searchb);
            this.panel1.Controls.Add(this.homeb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(80, 450);
            this.panel1.TabIndex = 32;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(5, 222);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 6;
            this.exit.Text = "exit";
            this.exit.UseVisualStyleBackColor = true;
            // 
            // editb
            // 
            this.editb.Location = new System.Drawing.Point(2, 184);
            this.editb.Name = "editb";
            this.editb.Size = new System.Drawing.Size(75, 23);
            this.editb.TabIndex = 5;
            this.editb.Text = "edit";
            this.editb.UseVisualStyleBackColor = true;
            // 
            // marksb
            // 
            this.marksb.Location = new System.Drawing.Point(2, 139);
            this.marksb.Name = "marksb";
            this.marksb.Size = new System.Drawing.Size(75, 23);
            this.marksb.TabIndex = 4;
            this.marksb.Text = "marks";
            this.marksb.UseVisualStyleBackColor = true;
            // 
            // deleteb
            // 
            this.deleteb.Location = new System.Drawing.Point(0, 110);
            this.deleteb.Name = "deleteb";
            this.deleteb.Size = new System.Drawing.Size(75, 23);
            this.deleteb.TabIndex = 3;
            this.deleteb.Text = "delete";
            this.deleteb.UseVisualStyleBackColor = true;
            // 
            // news
            // 
            this.news.Location = new System.Drawing.Point(2, 70);
            this.news.Name = "news";
            this.news.Size = new System.Drawing.Size(75, 23);
            this.news.TabIndex = 2;
            this.news.Text = "new";
            this.news.UseVisualStyleBackColor = true;
            // 
            // searchb
            // 
            this.searchb.Location = new System.Drawing.Point(2, 32);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(75, 23);
            this.searchb.TabIndex = 1;
            this.searchb.Text = "search";
            this.searchb.UseVisualStyleBackColor = true;
            // 
            // homeb
            // 
            this.homeb.Location = new System.Drawing.Point(0, 3);
            this.homeb.Name = "homeb";
            this.homeb.Size = new System.Drawing.Size(75, 23);
            this.homeb.TabIndex = 0;
            this.homeb.Text = "home";
            this.homeb.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(298, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 33;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Assignment",
            "Quiz",
            "MID"});
            this.comboBox1.Location = new System.Drawing.Point(504, 284);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 34;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            this.comboBox1.SelectedValueChanged += new System.EventHandler(this.ComboBox1_SelectedValueChanged);
            // 
            // Marks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Markss);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Names);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Departments);
            this.Controls.Add(this.Batchs);
            this.Controls.Add(this.IDs);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Marks";
            this.Text = "Marks";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Departments;
        private System.Windows.Forms.TextBox Batchs;
        private System.Windows.Forms.TextBox IDs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Names;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Markss;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button editb;
        private System.Windows.Forms.Button marksb;
        private System.Windows.Forms.Button deleteb;
        private System.Windows.Forms.Button news;
        private System.Windows.Forms.Button searchb;
        private System.Windows.Forms.Button homeb;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}