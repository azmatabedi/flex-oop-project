﻿namespace flex_system_last
{
    partial class Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Address = new System.Windows.Forms.TextBox();
            this.Phones = new System.Windows.Forms.TextBox();
            this.Departments = new System.Windows.Forms.TextBox();
            this.Batchs = new System.Windows.Forms.TextBox();
            this.Names = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Markss = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.editb = new System.Windows.Forms.Button();
            this.marksb = new System.Windows.Forms.Button();
            this.deleteb = new System.Windows.Forms.Button();
            this.news = new System.Windows.Forms.Button();
            this.searchb = new System.Windows.Forms.Button();
            this.homeb = new System.Windows.Forms.Button();
            this.Edits = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.IDs = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(310, 313);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(100, 20);
            this.Address.TabIndex = 29;
            // 
            // Phones
            // 
            this.Phones.Location = new System.Drawing.Point(310, 267);
            this.Phones.Name = "Phones";
            this.Phones.Size = new System.Drawing.Size(100, 20);
            this.Phones.TabIndex = 28;
            // 
            // Departments
            // 
            this.Departments.Location = new System.Drawing.Point(310, 216);
            this.Departments.Name = "Departments";
            this.Departments.Size = new System.Drawing.Size(100, 20);
            this.Departments.TabIndex = 27;
            // 
            // Batchs
            // 
            this.Batchs.Location = new System.Drawing.Point(310, 171);
            this.Batchs.Name = "Batchs";
            this.Batchs.Size = new System.Drawing.Size(100, 20);
            this.Batchs.TabIndex = 26;
            // 
            // Names
            // 
            this.Names.Location = new System.Drawing.Point(310, 122);
            this.Names.Name = "Names";
            this.Names.Size = new System.Drawing.Size(100, 20);
            this.Names.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(163, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(163, 274);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Phone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(163, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(163, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Batch";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(163, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Name";
            // 
            // Markss
            // 
            this.Markss.Location = new System.Drawing.Point(310, 363);
            this.Markss.Name = "Markss";
            this.Markss.Size = new System.Drawing.Size(100, 20);
            this.Markss.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(167, 370);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 32;
            this.label7.Text = "Marks";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.editb);
            this.panel1.Controls.Add(this.marksb);
            this.panel1.Controls.Add(this.deleteb);
            this.panel1.Controls.Add(this.news);
            this.panel1.Controls.Add(this.searchb);
            this.panel1.Controls.Add(this.homeb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(80, 450);
            this.panel1.TabIndex = 34;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(5, 222);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 6;
            this.exit.Text = "exit";
            this.exit.UseVisualStyleBackColor = true;
            // 
            // editb
            // 
            this.editb.Location = new System.Drawing.Point(2, 184);
            this.editb.Name = "editb";
            this.editb.Size = new System.Drawing.Size(75, 23);
            this.editb.TabIndex = 5;
            this.editb.Text = "edit";
            this.editb.UseVisualStyleBackColor = true;
            // 
            // marksb
            // 
            this.marksb.Location = new System.Drawing.Point(2, 139);
            this.marksb.Name = "marksb";
            this.marksb.Size = new System.Drawing.Size(75, 23);
            this.marksb.TabIndex = 4;
            this.marksb.Text = "marks";
            this.marksb.UseVisualStyleBackColor = true;
            // 
            // deleteb
            // 
            this.deleteb.Location = new System.Drawing.Point(0, 110);
            this.deleteb.Name = "deleteb";
            this.deleteb.Size = new System.Drawing.Size(75, 23);
            this.deleteb.TabIndex = 3;
            this.deleteb.Text = "delete";
            this.deleteb.UseVisualStyleBackColor = true;
            // 
            // news
            // 
            this.news.Location = new System.Drawing.Point(2, 70);
            this.news.Name = "news";
            this.news.Size = new System.Drawing.Size(75, 23);
            this.news.TabIndex = 2;
            this.news.Text = "new";
            this.news.UseVisualStyleBackColor = true;
            // 
            // searchb
            // 
            this.searchb.Location = new System.Drawing.Point(2, 32);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(75, 23);
            this.searchb.TabIndex = 1;
            this.searchb.Text = "search";
            this.searchb.UseVisualStyleBackColor = true;
            // 
            // homeb
            // 
            this.homeb.Location = new System.Drawing.Point(0, 3);
            this.homeb.Name = "homeb";
            this.homeb.Size = new System.Drawing.Size(75, 23);
            this.homeb.TabIndex = 0;
            this.homeb.Text = "home";
            this.homeb.UseVisualStyleBackColor = true;
            // 
            // Edits
            // 
            this.Edits.Location = new System.Drawing.Point(320, 403);
            this.Edits.Name = "Edits";
            this.Edits.Size = new System.Drawing.Size(75, 23);
            this.Edits.TabIndex = 35;
            this.Edits.Text = "Edit";
            this.Edits.UseVisualStyleBackColor = true;
            this.Edits.Click += new System.EventHandler(this.Edits_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "ID";
            // 
            // IDs
            // 
            this.IDs.Location = new System.Drawing.Point(310, 63);
            this.IDs.Name = "IDs";
            this.IDs.Size = new System.Drawing.Size(100, 20);
            this.IDs.TabIndex = 25;
            this.IDs.TextChanged += new System.EventHandler(this.IDs_TextChanged);
            // 
            // Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Edits);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Markss);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.Phones);
            this.Controls.Add(this.Departments);
            this.Controls.Add(this.Batchs);
            this.Controls.Add(this.IDs);
            this.Controls.Add(this.Names);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Edit";
            this.Text = "Edit";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox Phones;
        private System.Windows.Forms.TextBox Departments;
        private System.Windows.Forms.TextBox Batchs;
        private System.Windows.Forms.TextBox Names;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Markss;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button editb;
        private System.Windows.Forms.Button marksb;
        private System.Windows.Forms.Button deleteb;
        private System.Windows.Forms.Button news;
        private System.Windows.Forms.Button searchb;
        private System.Windows.Forms.Button homeb;
        private System.Windows.Forms.Button Edits;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox IDs;
    }
}