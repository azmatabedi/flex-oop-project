﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using System.Threading;

namespace flex_system_last
{
    public partial class Delete : Form
    {
        Teacher teacher;
        Student student;
       
        public Delete(Teacher teacher)
        {
            student = new Student();
            this.teacher = teacher;
            
            InitializeComponent();
        }
        IFirebaseClient client;
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5el7PEgL8sOhY7uACJt9VRYHtaC1O3No9nLXE02z",
            BasePath = "https://flex-system-30389.firebaseio.com/"
        };
        private void Delete_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);
            if (client == null)
            {
                MessageBox.Show("server not Responding");
            }
        }

        private async void deletes_Click(object sender, EventArgs e)
        {
            var id = IDs.Text;
            if (string.IsNullOrWhiteSpace(IDs.Text))
            {
                MessageBox.Show("Please Provide ID to Search");
            }
            client = new FireSharp.FirebaseClient(config);
            
            try
            {
                FirebaseResponse firebaseResponse = await client.GetTaskAsync(@"Information/student/" + id);
                student = firebaseResponse.ResultAs<Student>();
                Names.Text = student.Name;
                Address.Text = student.Address;
                Batchs.Text = student.Batch;
                Phones.Text = student.Phone;
                Departments.Text = student.Ds;
                try
                {
                    FirebaseResponse deleteResponse = await client.DeleteTaskAsync("Information/student/" + id);
                    MessageBox.Show("Student Deleted!");
                }
                catch
                {
                    MessageBox.Show("Student Not Deleted!");
                }
                undo.Enabled = true;
            }
            catch
            {
                MessageBox.Show("ID not Found - Please Check Your Internet Connection");
            }
        }

        private void undo_Click(object sender, EventArgs e)
        {
            try
            {
                SetResponse setResponse = client.Set(@"Information/student/" + student.Id, student);
                MessageBox.Show("Student Added Successfully");
                undo.Enabled = false;
            }
            catch
            {
                MessageBox.Show("Student Can't Undo");
            }
        }
    }
}
