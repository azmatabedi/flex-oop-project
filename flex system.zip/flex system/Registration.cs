﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
namespace flex_system_last
{
    public partial class Registration : Form
    {
        public IFirebaseClient client;
        public Registration()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
        }
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5el7PEgL8sOhY7uACJt9VRYHtaC1O3No9nLXE02z",
            BasePath = "https://flex-system-30389.firebaseio.com/"
        };
        private void Signup_Click(object sender, EventArgs e)
        {
            string name = Namet.Text;
            string Gender = Gendert.Text;
            string DOB = DOBt.Text;
            string Department = Departmentt.Text;
            string CNIC = CNICt.Text;
            string password = passwordt.Text;

            Teacher teacher = new Teacher(name, Gender, DOB, Department, CNIC, password);
            try
            {
                SetResponse setResponse = client.Set(@"Information/Teacher/" + teacher.Name, teacher);
                MessageBox.Show("Welcome " + teacher.Name);
            }
            catch
            {
                MessageBox.Show("Fuck You");
            }
        }
       
    }
}
