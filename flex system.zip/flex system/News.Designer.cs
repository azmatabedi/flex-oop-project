﻿namespace flex_system_last
{
    partial class News
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.Phones = new System.Windows.Forms.TextBox();
            this.Departments = new System.Windows.Forms.TextBox();
            this.Batchs = new System.Windows.Forms.TextBox();
            this.IDs = new System.Windows.Forms.TextBox();
            this.Names = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.editb = new System.Windows.Forms.Button();
            this.marksb = new System.Windows.Forms.Button();
            this.deleteb = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.searchb = new System.Windows.Forms.Button();
            this.homeb = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Upload = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(97, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Phone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(97, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Batch";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(97, 322);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Address";
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(257, 354);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 16;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Phones
            // 
            this.Phones.Location = new System.Drawing.Point(244, 269);
            this.Phones.Name = "Phones";
            this.Phones.Size = new System.Drawing.Size(100, 20);
            this.Phones.TabIndex = 15;
            // 
            // Departments
            // 
            this.Departments.Location = new System.Drawing.Point(244, 218);
            this.Departments.Name = "Departments";
            this.Departments.Size = new System.Drawing.Size(100, 20);
            this.Departments.TabIndex = 14;
            // 
            // Batchs
            // 
            this.Batchs.Location = new System.Drawing.Point(244, 173);
            this.Batchs.Name = "Batchs";
            this.Batchs.Size = new System.Drawing.Size(100, 20);
            this.Batchs.TabIndex = 13;
            // 
            // IDs
            // 
            this.IDs.Location = new System.Drawing.Point(244, 121);
            this.IDs.Name = "IDs";
            this.IDs.Size = new System.Drawing.Size(100, 20);
            this.IDs.TabIndex = 12;
            // 
            // Names
            // 
            this.Names.Location = new System.Drawing.Point(244, 72);
            this.Names.Name = "Names";
            this.Names.Size = new System.Drawing.Size(100, 20);
            this.Names.TabIndex = 11;
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(244, 315);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(100, 20);
            this.Address.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.exit);
            this.panel1.Controls.Add(this.editb);
            this.panel1.Controls.Add(this.marksb);
            this.panel1.Controls.Add(this.deleteb);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.searchb);
            this.panel1.Controls.Add(this.homeb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(80, 450);
            this.panel1.TabIndex = 21;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(5, 222);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 6;
            this.exit.Text = "exit";
            this.exit.UseVisualStyleBackColor = true;
            // 
            // editb
            // 
            this.editb.Location = new System.Drawing.Point(2, 184);
            this.editb.Name = "editb";
            this.editb.Size = new System.Drawing.Size(75, 23);
            this.editb.TabIndex = 5;
            this.editb.Text = "edit";
            this.editb.UseVisualStyleBackColor = true;
            // 
            // marksb
            // 
            this.marksb.Location = new System.Drawing.Point(2, 139);
            this.marksb.Name = "marksb";
            this.marksb.Size = new System.Drawing.Size(75, 23);
            this.marksb.TabIndex = 4;
            this.marksb.Text = "marks";
            this.marksb.UseVisualStyleBackColor = true;
            // 
            // deleteb
            // 
            this.deleteb.Location = new System.Drawing.Point(0, 110);
            this.deleteb.Name = "deleteb";
            this.deleteb.Size = new System.Drawing.Size(75, 23);
            this.deleteb.TabIndex = 3;
            this.deleteb.Text = "delete";
            this.deleteb.UseVisualStyleBackColor = true;
            this.deleteb.Click += new System.EventHandler(this.deleteb_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "new";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // searchb
            // 
            this.searchb.Location = new System.Drawing.Point(2, 32);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(75, 23);
            this.searchb.TabIndex = 1;
            this.searchb.Text = "search";
            this.searchb.UseVisualStyleBackColor = true;
            // 
            // homeb
            // 
            this.homeb.Location = new System.Drawing.Point(0, 3);
            this.homeb.Name = "homeb";
            this.homeb.Size = new System.Drawing.Size(75, 23);
            this.homeb.TabIndex = 0;
            this.homeb.Text = "home";
            this.homeb.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(577, 119);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // Upload
            // 
            this.Upload.Location = new System.Drawing.Point(577, 253);
            this.Upload.Name = "Upload";
            this.Upload.Size = new System.Drawing.Size(75, 23);
            this.Upload.TabIndex = 23;
            this.Upload.Text = "Browser";
            this.Upload.UseVisualStyleBackColor = true;
            this.Upload.Click += new System.EventHandler(this.Upload_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(621, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Upload picture";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(683, 253);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "Insert";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // News
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Upload);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Phones);
            this.Controls.Add(this.Departments);
            this.Controls.Add(this.Batchs);
            this.Controls.Add(this.IDs);
            this.Controls.Add(this.Names);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "News";
            this.Text = "News";
            this.Load += new System.EventHandler(this.News_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox Phones;
        private System.Windows.Forms.TextBox Departments;
        private System.Windows.Forms.TextBox Batchs;
        private System.Windows.Forms.TextBox IDs;
        private System.Windows.Forms.TextBox Names;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button editb;
        private System.Windows.Forms.Button marksb;
        private System.Windows.Forms.Button deleteb;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button searchb;
        private System.Windows.Forms.Button homeb;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Upload;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button2;
    }
}