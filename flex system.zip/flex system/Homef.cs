﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace flex_system_last
{
    public partial class Homef : Form
    {
        Teacher teacher;
        public Homef(Teacher teacher)
        {
            this.teacher = teacher;
            InitializeComponent();
        }

        private void Homef_Load(object sender, EventArgs e)
        {

        }

        private void Searchb_Click(object sender, EventArgs e)
        {
            Search search = new Search(teacher);
            this.Hide();
            search.Show();
        }

        private void News_Click(object sender, EventArgs e)
        {
            News news = new News(teacher);
            this.Hide();
            news.Show();
        }

        private void deleteb_Click(object sender, EventArgs e)
        {
            Delete delete = new Delete(teacher);
            this.Hide();
            delete.Show();
        }
    }
}
